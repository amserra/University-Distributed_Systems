De forma a correr a meta1, basta:

1) Abrir a pasta out/production/Meta1
2) Correr, por esta ordem:

	java RMIServer(1 ou 2)
	java MulticastServer(os que quiser)
	java RMIClient (se necessário, os que quiser)

Para correr a meta2, o ficheiro .war encontra-se em: out/artifacts/Meta2